import pygame, sys
from pygame.locals import *

pygame.init()

# definición del ancho y alto de la ventana
ANCHO = 800
ALTO = 600

BLANCO = (255, 255, 255)

ventana = pygame.display.set_mode((ANCHO,ALTO))
pygame.display.set_caption("Movimiento")

# cargamos la imagen original (mirando a la derecha)
dragon_derecha = pygame.image.load("imagenes/dragon.png")

# creamos la versión volteada
dragon_izquierda = pygame.transform.flip(dragon_derecha, True, False)

# imagen actual
Mi_imagen = dragon_derecha

# definición de posición inicial
posX, posY =400, 200
X , Y = 30, 30
X2 , Y2 = 50, 50

# se establece la velocidad inicial
velocidad = 3

# la direccion en positivo indicará Derecha y en negativo indicará Izquierda
direccion = 1

# reloj para controlar FPS
clock = pygame.time.Clock()

VERDECITO=(0,255,186)
jugando="si"

while jugando=="si":

    for evento in pygame.event.get():
        if evento.type == QUIT:
            jugando="no"
            
            

    ventana.fill(BLANCO)

    teclas = pygame.key.get_pressed()
    if teclas[pygame.K_RIGHT]:
        X=X+10 #desplazo el rectángulo
    if teclas[pygame.K_LEFT]:
        X=X-10 #desplazo a la izquierda
    if teclas[pygame.K_UP]:
        Y=Y-10
    if teclas[pygame.K_DOWN]:
        Y=Y+10
    if teclas[pygame.K_a]:
        if X2>0:
            X2=X2-10
    if teclas[pygame.K_d]:
        X2=X2+10
    pygame.draw.rect(ventana,(0,0,255),(X,Y,50,50))
    pygame.draw.rect(ventana,(255,0,0),(X2,Y2,50,50))
    # se muestra la imagen en las coordenadas actuales
    ventana.blit(Mi_imagen, (posX, posY))

    

    pygame.display.flip()
    clock.tick(60)

    
pygame.quit()